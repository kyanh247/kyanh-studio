# Kỳ Anh Reply — bản 1.0.0

Ảnh chụp toàn bộ app tại ngày **17/08/2026**. Đây là mốc ổn định đầu tiên,
dùng để quay về nếu các bản sau có trục trặc.

## Trong gói này có gì

| File | Là gì |
|---|---|
| `index.html` | Toàn bộ app (giao diện + xử lý + cấu hình) |
| `assets/favicon/` | Logo hiện trên tab trình duyệt |
| `replies-backup.json` | 70 mẫu trả lời tại thời điểm đóng gói |
| `khoi-phuc.py` | Script nạp lại mẫu lên Firebase khi bị mất |
| `sao-luu.py` | Script tải mẫu từ Firebase về máy |

## Bản này có gì

- Menu: All / Chốt Đơn / Tư Vấn / Bảng Giá / Gần Đây
- Bảng Giá chia 6 mục: Concept, Portrait, Ảnh Bầu, Birthday, Couple, Truyền Thống
- Mẫu điền nhanh `{{Tên mục}}`, khối lặp `[[Concept]]`, đánh số `{{#}}`
- `{{*Tên mục}}` → chữ điền vào tự in đậm kiểu 𝐛𝐨𝐥𝐝
- `{{Giảm %}}` → tự tính từ `{{Giá gốc}}` và `{{Giá khuyến mãi}}`
- Quản trị bằng **đăng nhập email/mật khẩu** (Firebase Auth)
- Chạy tại `reply.kyanh.studio`, dữ liệu đồng bộ realtime qua Firestore

## Việc còn dở tại thời điểm đóng gói

**Firestore Rules chưa được siết.** Lúc đóng gói, luật cũ vẫn đang chạy —
nghĩa là gửi lệnh xoá không kèm gì vẫn xoá được dữ liệu. Code đã sẵn sàng
cho luật mới, chỉ còn thiếu bước dán luật vào Console và bấm Publish.
Xem đoạn luật trong phần ghi chú cuối `index.html`.

## Cách quay về bản này

Chép đè `index.html` và thư mục `assets/` vào thư mục gốc của repo, rồi
`git commit` + `git push`. Muốn khôi phục cả dữ liệu thì chép
`replies-backup.json` vào thư mục `backup/` rồi chạy:

```bash
python backup/khoi-phuc.py          # xem trước
python backup/khoi-phuc.py --that   # nạp thật
```
